---
domain:
category:
  - idea
related:
aliases:
---

Idea:



